package Excepciones;

/**

 * @author MIGUEL
 */
public class CampoVacio extends Exception{
    
}
